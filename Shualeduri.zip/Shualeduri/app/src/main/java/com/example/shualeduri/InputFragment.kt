package com.example.shualeduri

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment

import android.view.LayoutInflater
import android.view.ViewGroup
import com.example.shualeduri.databinding.FragmentInputFragmentBinding

class InputFragment : Fragment() {

    private var _binding: FragmentInputFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInputFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.mchBtnCalculate.setOnClickListener {
            val model = FinanceModel(
                binding.mchEditSalary.text.toString().toDoubleOrNull() ?: 0.0,
                binding.mchEditRent.text.toString().toDoubleOrNull() ?: 0.0,
                binding.mchEditFood.text.toString().toDoubleOrNull() ?: 0.0
            )

            parentFragmentManager.beginTransaction()
                .replace(R.id.mch_fragment_container, ResultFragment().apply {
                    arguments = Bundle().apply {
                        putSerializable("DATA", model)
                    }
                })
                .addToBackStack(null)
                .commit()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}