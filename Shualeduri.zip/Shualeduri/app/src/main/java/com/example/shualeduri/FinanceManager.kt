package com.example.shualeduri

class FinanceManager {
    // ჩახუნაშვილი (11 ასო) + აპრილი (მე-4 თვე) = 15%
    val savingsPercent = 11 + 4

    fun calculateRemaining(salary: Double, rent: Double, food: Double): Double {
        return salary - (rent + food)
    }

    fun calculateSavings(salary: Double): Double {
        return (salary * savingsPercent) / 100
    }
}