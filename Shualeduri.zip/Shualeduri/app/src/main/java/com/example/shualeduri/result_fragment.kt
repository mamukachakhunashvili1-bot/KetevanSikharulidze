package com.example.shualeduri

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment

import android.view.LayoutInflater
import android.view.ViewGroup
import com.example.shualeduri.databinding.FragmentResultFragmentBinding

class ResultFragment : Fragment() {

    private var _binding: FragmentResultFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentResultFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val model = arguments?.getSerializable("DATA") as? FinanceModel
        
        if (model != null) {
            val manager = FinanceManager()
            val remaining = manager.calculateRemaining(model.salary, model.rent, model.food)
            val savings = manager.calculateSavings(model.salary)

            binding.mchTxtResult.text = getString(R.string.result_format, remaining, manager.savingsPercent, savings)
            
            // Dynamic Identity from Kotlin
            binding.mchTxtIdentity.text = "მამუკა ჩახუნაშვილი, 2007 წელი"

            if (model.salary < (model.rent + model.food)) {
                binding.mchTxtResult.setTextColor(Color.RED)
            } else {
                binding.mchTxtResult.setTextColor(Color.GREEN)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}