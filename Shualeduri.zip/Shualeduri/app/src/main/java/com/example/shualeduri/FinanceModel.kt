package com.example.shualeduri

import java.io.Serializable

data class FinanceModel(
    val salary: Double,
    val rent: Double,
    val food: Double
) : Serializable