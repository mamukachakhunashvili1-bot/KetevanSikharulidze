package com.example.davaleba

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.davaleba.databinding.ActivityPage2Binding

class page2 : AppCompatActivity() {

    private lateinit var binding: ActivityPage2Binding
    private var shippingCost = 0
    private var carPrice = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPage2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        // 1. მონაცემების მიღება
        val carImageRes = intent.getIntExtra("CAR_IMAGE", 0)
        val carName = intent.getStringExtra("CAR_NAME") ?: "Unknown Car"
        carPrice = intent.getIntExtra("CAR_PRICE", 0)

        // 2. UI-ის შევსება
        if (carImageRes != 0) {
            binding.carPicture.setImageResource(carImageRes)
        }
        binding.carNameText.text = carName
        binding.carFee.text = "$%,d".format(carPrice)

        updateTotal()

        // 3. Shipping Options ლოგიკა
        binding.radioButtonStandart.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                shippingCost = 0
                updateTotal()
            }
        }

        binding.radioButtonExpress.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                shippingCost = 1700
                updateTotal()
            }
        }

        // 4. Pay ღილაკი
        binding.payButton.setOnClickListener {
            // აქ დაწერე სადაც გინდა რომ გადავიდეს (მაგ. ThirdActivity)
            // val intent = Intent(this, ThirdActivity::class.java)
            // startActivity(intent)
        }
    }

    private fun updateTotal() {
        val total = carPrice + shippingCost
        binding.totalFee.text = "$%,d".format(total)
    }
}