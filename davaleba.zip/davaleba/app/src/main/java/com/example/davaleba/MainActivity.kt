package com.example.davaleba

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.davaleba.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // BMW
        binding.carBMW.setOnClickListener {
            navigateToPayment(R.drawable.bmw, "BMW M3 (F80)", 38000)
        }

        // Porsche
        binding.carPorsche.setOnClickListener {
            navigateToPayment(R.drawable.porsche, "Porsche 911 GT3 RS", 189000)
        }

        // Mercedes
        binding.carMERC.setOnClickListener {
            navigateToPayment(R.drawable.merc, "Mercedes CLA", 46400)
        }

        // Ferrari
        binding.carFerrari.setOnClickListener {
            navigateToPayment(R.drawable.ferrari, "Ferrari 488 Spider", 260000)
        }
    }

    private fun navigateToPayment(imageRes: Int, name: String, price: Int) {
        // აქ page2 უნდა იყოს, თუ მეორე Activity-ს ეგრე ქვია
        val intent = Intent(this, page2::class.java).apply {
            putExtra("CAR_IMAGE", imageRes)
            putExtra("CAR_NAME", name)
            putExtra("CAR_PRICE", price)
        }
        startActivity(intent)
    }
}